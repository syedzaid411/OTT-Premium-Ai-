const ids = ["site", "code", "region", "lang"];
chrome.storage.sync.get(ids, (o) => ids.forEach((k) => { if (o[k]) document.getElementById(k).value = o[k]; }));
document.getElementById("save").onclick = () => {
  const v = {};
  ids.forEach((k) => (v[k] = document.getElementById(k).value.trim()));
  chrome.storage.sync.set(v, () => (document.getElementById("m").textContent = "✅ محفوظ ہو گیا"));
};
