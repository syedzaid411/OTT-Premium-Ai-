chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());

chrome.runtime.onMessage.addListener((msg, _s, send) => {
  if (msg.type !== "ask") return;
  (async () => {
    try {
      const o = await chrome.storage.sync.get(["site", "code", "region", "lang"]);
      if (!o.site || !o.code) return send({ error: "پہلے ایکسٹینشن کی سیٹنگ میں سائٹ کا لنک اور کوڈ ڈالیں (ٹول بار میں آئیکن دبائیں)۔" });
      const region = o.region || "PK", lang = o.lang || "Urdu (Urdu script)";
      const call = async (type, b) => {
        const r = await fetch(o.site.replace(/\/$/, "") + "/.netlify/functions/api", {
          method: "POST",
          headers: { "x-code": o.code, "content-type": "application/json" },
          body: JSON.stringify({ type, ...b }),
        });
        if (r.status === 401) throw new Error("کوڈ غلط ہے");
        if (!r.ok) throw new Error("سرور ایرر " + r.status);
        return r.json();
      };
      const s = await call("tmdb", { path: "/search/multi", params: { query: msg.title, language: "en-US" } });
      const m = (s.results || []).find((x) => x.media_type !== "person") || {};
      let where = "";
      if (m.id) {
        const w = await call("tmdb", { path: `/${m.media_type}/${m.id}/watch/providers`, params: {} }).catch(() => null);
        const pv = w && w.results && w.results[region];
        if (pv) where = [...(pv.flatrate || []), ...(pv.rent || []), ...(pv.buy || [])].map((x) => x.provider_name).join(", ");
      }
      const name = m.title || m.name || msg.title;
      const a = await call("ai", { messages: [{ role: "user", content:
        `You are a movie expert. Reply in ${lang}. Short clear points: 1) type and mood 2) story in 2 lines, NO spoilers 3) who should watch / skip 4) where to watch (only from: ${where || "unknown"}) 5) verdict out of 10. Title: ${name}. Rating: ${m.vote_average || "?"}. Plot: ${m.overview || ""}` }] });
      send({
        title: name,
        year: (m.release_date || m.first_air_date || "").slice(0, 4),
        rating: m.vote_average ? m.vote_average.toFixed(1) : "",
        poster: m.poster_path ? "https://image.tmdb.org/t/p/w185" + m.poster_path : "",
        where,
        text: a.choices[0].message.content,
      });
    } catch (e) { send({ error: String(e.message || e) }); }
  })();
  return true;
});
