(() => {
  if (window.top !== window || document.getElementById("ott-injector-host")) return;
  const host = document.createElement("div");
  host.id = "ott-injector-host";
  const root = host.attachShadow({ mode: "open" });
  root.innerHTML = `
  <style>
    *{box-sizing:border-box;font-family:system-ui,"Noto Sans Arabic",Tahoma,sans-serif}
    #fab{position:fixed;z-index:2147483647;bottom:20px;left:20px;width:54px;height:54px;border-radius:50%;border:0;cursor:pointer;font-size:24px;background:#4fe0c4;color:#07201b;box-shadow:0 8px 24px rgba(0,0,0,.55)}
    #pn{position:fixed;z-index:2147483647;bottom:84px;left:20px;width:min(380px,calc(100vw - 40px));max-height:75vh;overflow:auto;background:#1d1829;color:#f2ecf7;border:1px solid #3b3253;border-radius:18px;padding:16px;box-shadow:0 20px 60px #000;display:none;direction:rtl}
    #pn.o{display:block}
    input{width:100%;padding:10px 12px;border-radius:12px;border:1px solid #3b3253;background:#271f38;color:inherit;font-size:15px}
    button.go{margin-top:10px;width:100%;padding:10px;border:0;border-radius:12px;background:#4fe0c4;color:#07201b;font-weight:800;font-size:15px;cursor:pointer}
    #out{margin-top:12px;white-space:pre-wrap;line-height:1.9;font-size:15px}
    .row{display:flex;gap:12px;align-items:flex-start;margin-bottom:8px}
    .row img{width:70px;border-radius:8px}
    small{color:#a89fbd}
  </style>
  <button id="fab" title="OTT Injector">🎬</button>
  <div id="pn"><input id="t" placeholder="فلم یا سیریز کا نام"><button class="go" id="go">💉 تفصیل بتاؤ</button><div id="out"></div></div>`;
  document.documentElement.appendChild(host);
  const $ = (s) => root.querySelector(s);
  const guess = () => {
    let t = (getSelection() + "").trim() || (document.querySelector('meta[property="og:title"]') || {}).content || document.title || "";
    return t.replace(/\s*[-|–]\s*(Netflix|Prime Video|IMDb|Watch.*)$/i, "").trim();
  };
  $("#fab").onclick = () => {
    const p = $("#pn");
    p.classList.toggle("o");
    if (p.classList.contains("o")) { $("#t").value = guess(); }
  };
  const run = () => {
    const title = $("#t").value.trim(), out = $("#out");
    if (!title) return;
    out.textContent = "🔎 AI دیکھ رہا ہے…";
    chrome.runtime.sendMessage({ type: "ask", title }, (r) => {
      out.textContent = "";
      if (!r || r.error) { out.textContent = (r && r.error) || "جواب نہیں ملا"; return; }
      const row = document.createElement("div"); row.className = "row";
      if (r.poster) { const i = document.createElement("img"); i.src = r.poster; row.append(i); }
      const h = document.createElement("div");
      h.innerHTML = "<b></b><br><small></small>";
      h.querySelector("b").textContent = r.title + (r.year ? " (" + r.year + ")" : "");
      h.querySelector("small").textContent = (r.rating ? "★ " + r.rating : "") + (r.where ? "  ·  " + r.where : "");
      row.append(h);
      const body = document.createElement("div"); body.textContent = r.text;
      out.append(row, body);
    });
  };
  $("#go").onclick = run;
  $("#t").onkeydown = (e) => { e.stopPropagation(); if (e.key === "Enter") run(); };
  $("#t").onkeyup = $("#t").onkeypress = (e) => e.stopPropagation();
})();
